document.addEventListener('DOMContentLoaded', function () {
    renderCartItems();
});

function renderCartItems() {
    const cartItems = JSON.parse(localStorage.getItem('cart')) || [];
    const cartContainer = document.getElementById('cart-items');
    cartContainer.innerHTML = '';

    if (cartItems.length === 0) {
        cartContainer.innerHTML = '<p>Your cart is empty.</p>';
    } else {
        cartItems.forEach((item, index) => {
            const productElement = document.createElement('div');
            productElement.className = 'cart-item';
            productElement.innerHTML = `
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <div>
                        <h5>${item.name}</h5>
                        <p>Price: $${item.price.toFixed(2)}</p>
                    </div>
                    <button class="btn btn-danger btn-sm" onclick="removeFromCart(${index})">Remove</button>
                </div>
            `;
            cartContainer.appendChild(productElement);
        });
    }
}

function addToCart(productName, productPrice) {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    cart.push({ name: productName, price: productPrice });
    localStorage.setItem('cart', JSON.stringify(cart));
    alert(`${productName} has been added to your cart.`);
}

function removeFromCart(index) {
    let cart = JSON.parse(localStorage.getItem('cart')) || [];
    cart.splice(index, 1);
    localStorage.setItem('cart', JSON.stringify(cart));
    renderCartItems();
}

function clearCart() {
    localStorage.removeItem('cart');
    renderCartItems();
}

function validateForm() {
    const cartItems = JSON.parse(localStorage.getItem('cart')) || [];
    if (cartItems.length === 0) {
        alert('Please add at least one product to the cart.');
        return false;
    }

    const firstName = document.getElementById('firstName').value.trim();
    const lastName = document.getElementById('lastName').value.trim();
    const phoneNumber = document.getElementById('phoneNumber').value.trim();
    const email = document.getElementById('email').value.trim();
    const address = document.getElementById('address').value.trim();

    if (!firstName || !lastName || !phoneNumber || !email || !address) {
        alert('Please fill in all the required fields.');
        return false;
    }

    generateAndDownloadBill(cartItems, firstName, lastName, phoneNumber, email, address);
    return false; // Prevent form submission
}

function generateAndDownloadBill(cartItems, firstName, lastName, phoneNumber, email, address) {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();

    // Set the starting position
    let y = 10;

    // Title
    doc.setFontSize(18);
    doc.text('Bill', 10, y);
    y += 10;

    // User Information
    doc.setFontSize(12);
    doc.text(`Name: ${firstName} ${lastName}`, 10, y);
    y += 10;
    doc.text(`Phone: ${phoneNumber}`, 10, y);
    y += 10;
    doc.text(`Email: ${email}`, 10, y);
    y += 10;
    doc.text(`Address: ${address}`, 10, y);
    y += 15;

    // Products
    doc.text('Products:', 10, y);
    y += 10;

    let total = 0;
    cartItems.forEach(item => {
        doc.text(`${item.name} - $${item.price.toFixed(2)}`, 10, y);
        y += 10;
        total += item.price;
    });

    // Total
    y += 10;
    doc.text(`Total: $${total.toFixed(2)}`, 10, y);

    // Save PDF
    doc.save('bill.pdf');

    // Clear cart after generating the bill
    localStorage.removeItem('cart');
    renderCartItems();
}

function placeOrder() {
    const cartItems = JSON.parse(localStorage.getItem('cart')) || [];
    const firstName = document.getElementById('firstName').value.trim();
    const lastName = document.getElementById('lastName').value.trim();
    const phoneNumber = document.getElementById('phoneNumber').value.trim();
    const email = document.getElementById('email').value.trim();
    const address = document.getElementById('address').value.trim();

    if (!firstName || !lastName || !phoneNumber || !email || !address) {
        alert('Please fill in all required fields.');
        return;
    }

    fetch('/checkout', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            firstName,
            lastName,
            phoneNumber,
            email,
            address
        })
    })
    .then(response => response.text())
    .then(result => {
        alert('Order was placed successfully!');
        localStorage.removeItem('cart'); // Clear cart after placing order
        renderCartItems();
    })
    .catch(error => {
        console.error('Error:', error);
        alert('There was an error placing your order.');
    });
}
