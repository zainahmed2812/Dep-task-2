CREATE DATABASE e_commerce;
USE e_commerce;
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(255) NOT NULL,
    last_name VARCHAR(255) NOT NULL,
    phone_number VARCHAR(15),
    email VARCHAR(255) UNIQUE NOT NULL,
    address TEXT
);
CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL,
    image VARCHAR(255) -- Path to the product image
);
CREATE TABLE cart_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    product_id INT,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);
INSERT INTO products (name, description, price, image) VALUES
('Product 1', 'Description for product 1', 29.99, 'p1.jpeg'),
('Product 2', 'Description for product 2', 49.99, 'p2.jpeg'),
('Product 3', 'Description for product 3', 19.99, 'p3.jpeg'),
('Product 4', 'Description for product 4', 39.99, 'p4.jpeg');
SHOW TABLES;
select* from users;
select* from products;
select* from cart_items;
USE e_commerce;
INSERT INTO products (name, description, price, image) VALUES ('Product 1', 'Description for product 1', 29.99, 'p1.jpeg');



