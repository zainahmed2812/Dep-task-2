const express = require('express');
const bodyParser = require('body-parser');
const db = require('./database');

const app = express();
const PORT = 3000;

app.use(bodyParser.json());
app.use(express.static('public'));

// Fetch all blogs
app.get('/blogs', (req, res) => {
    db.query('SELECT * FROM blogs', (err, results) => {
        if (err) {
            res.status(500).send(err.message);
            return;
        }
        res.json(results);
    });
});

// Add a new blog
app.post('/blogs', (req, res) => {
    const { title, content } = req.body;
    db.query('INSERT INTO blogs (title, content) VALUES (?, ?)', [title, content], (err, result) => {
        if (err) {
            res.status(500).send(err.message);
            return;
        }
        res.status(201).send({ id: result.insertId });
    });
});

// Delete a blog
app.delete('/blogs/:id', (req, res) => {
    const { id } = req.params;
    db.query('DELETE FROM blogs WHERE id = ?', [id], (err, result) => {
        if (err) {
            res.status(500).send(err.message);
            return;
        }
        res.status(200).send({ deletedID: id });
    });
});

// Edit a blog
app.put('/blogs/:id', (req, res) => {
    const { id } = req.params;
    const { title, content } = req.body;
    db.query('UPDATE blogs SET title = ?, content = ? WHERE id = ?', [title, content, id], (err, result) => {
        if (err) {
            res.status(500).send(err.message);
            return;
        }
        res.status(200).send({ updatedID: id });
    });
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
