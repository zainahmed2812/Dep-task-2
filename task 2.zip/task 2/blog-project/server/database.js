const mysql2 = require('mysql2');
const connection = mysql2.createConnection({
    host: 'localhost',      // Your MySQL host
    user: 'root',   // Your MySQL username
    password: '28122002Zain@', // Your MySQL password
    database: 'blog_db'     // The database you created
});

connection.connect((err) => {
    if (err) throw err;
    console.log('Connected to the MySQL database.');
});

module.exports = connection;
